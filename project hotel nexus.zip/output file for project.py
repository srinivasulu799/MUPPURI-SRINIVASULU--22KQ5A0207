Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

============== RESTART: C:\Users\manoh\OneDrive\Desktop\hotel 2.py =============
			WELCOME TO THE HOTEL MASTER NEXUS

Hotel Management :
1. Display available hotels
2. Book a room
3. Display booking records
4. Exit
Enter your choice: 1
Available Hotels:
Hotel PK: Rooms available: 10, Price per night: $100
Hotel MSD: Rooms available: 20, Price per night: $120
Hotel NBK: Rooms available: 15, Price per night: $150
Hotel CBN: Rooms available: 12, Price per night: $200
Hotel JSP: Rooms available: 8, Price per night: $250

Hotel Management :
1. Display available hotels
2. Book a room
3. Display booking records
4. Exit
Enter your choice: 2
Enter hotel name to book: Hotel NBK
Enter your name: manohar
Enter check-in date (YYYY-MM-DD): 2024-06-11
Enter check-out date (YYYY-MM-DD): 2024-06-13
Total price for 2 nights: $300
Confirm booking (yes/no): yes
Booking confirmed.

Hotel Management :
1. Display available hotels
2. Book a room
3. Display booking records
4. Exit
Enter your choice: 3
Booking Records:
Booking 1:
Hotel: Hotel NBK
Name: manohar
Check-in Date: 2024-06-11
Check-out Date: 2024-06-13
Total Price: $300

Hotel Management :
1. Display available hotels
2. Book a room
3. Display booking records
4. Exit
Enter your choice: 4
Exiting program.
